# Deployment Guide for ScheduleAlert

This document provides step-by-step instructions to deploy your ScheduleAlert application to various free hosting platforms.

## Option 1: Render (Recommended Free Option)

Render offers a free tier that can host your entire full-stack application.

### Steps:

1. **Create a GitHub repository**
   - Push your code to a new GitHub repository

2. **Sign up for Render**
   - Go to [render.com](https://render.com/) and sign up for a free account
   - Connect your GitHub account

3. **Create a Web Service**
   - From your dashboard, click "New" and select "Web Service"
   - Connect your GitHub repository
   - Configure the service:
     - Name: `schedule-alert` (or your preferred name)
     - Runtime: `Node`
     - Build Command: `npm install && cd client && npm install && npm run build && cd ..`
     - Start Command: `npm start` (or `NODE_ENV=production node server/index.js`)
     - Instance Type: Free (free tier)

4. **Environment Variables**
   - Add any necessary environment variables:
     - `NODE_ENV`: `production`
     - `SESSION_SECRET`: Generate a random string for security

5. **Deploy**
   - Click "Create Web Service"
   - Render will automatically build and deploy your application
   - Your app will be available at `https://your-app-name.onrender.com`

## Option 2: Netlify + Railway

This approach separates your frontend and backend across two platforms.

### Frontend on Netlify:

1. **Create a build script**
   - Add this to your package.json:
   ```json
   "scripts": {
     "build:client": "cd client && npm install && npm run build"
   }
   ```

2. **Sign up for Netlify**
   - Go to [netlify.com](https://www.netlify.com/) and create an account
   - Connect your GitHub repository
   - Configure build settings:
     - Build command: `npm run build:client`
     - Publish directory: `client/dist`
   - Configure redirects for SPA routing by creating a `_redirects` file in the client/public directory:
   ```
   /* /index.html 200
   ```

3. **Deploy frontend**
   - Click "Deploy site"

### Backend on Railway:

1. **Sign up for Railway**
   - Go to [railway.app](https://railway.app/) and create an account
   - Install the Railway CLI: `npm i -g @railway/cli`
   - Log in: `railway login`

2. **Create a new project**
   - `railway init`
   - Configure as a Node.js project

3. **Deploy backend**
   - `railway up`
   - Set environment variables:
     - `NODE_ENV`: `production`
     - `FRONTEND_URL`: Your Netlify URL for CORS
     - `SESSION_SECRET`: A random string

4. **Update frontend API calls**
   - Update your frontend API calls to point to your Railway backend URL

## Option 3: Fly.io (Free Tier)

Fly.io offers a generous free tier that works well for full-stack applications.

### Steps:

1. **Install Flyctl**
   - Follow instructions on [fly.io/docs/hands-on/install-flyctl/](https://fly.io/docs/hands-on/install-flyctl/)

2. **Sign up and authenticate**
   - `flyctl auth signup`
   - Or login: `flyctl auth login`

3. **Create a Dockerfile** in your project root:
```Dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm install

COPY . .
RUN cd client && npm install && npm run build

ENV NODE_ENV=production
EXPOSE 8080

CMD ["node", "server/index.js"]
```

4. **Create a fly.toml file**
   - Run: `flyctl launch`
   - This creates a fly.toml configuration file
   - Follow the prompts (you can select the free tier)

5. **Deploy**
   - `flyctl deploy`
   - Your app will be available at `https://your-app-name.fly.dev`

## Important Notes for Any Deployment

### 1. Database Considerations
- The current app uses in-memory storage which resets when the server restarts
- For production, consider using a persistent database:
  - For free options: ElephantSQL (PostgreSQL), MongoDB Atlas, or Supabase

### 2. Environment Variables
- Always use environment variables for secrets and configuration
- Never commit sensitive information to your repository

### 3. CORS Configuration
- If deploying frontend and backend separately, ensure proper CORS configuration

### 4. Sessions and Security
- Use HTTPS URLs for all production deployments
- Ensure secure cookie settings for production